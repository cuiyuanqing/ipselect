#!/bin/sh
set -e
DIR="$(cd "$(dirname "$0")" && pwd)"
BACKUP_CFG="/tmp/ipselect_config.bak"
rm -f "$BACKUP_CFG" 2>/dev/null || true
[ -f "/etc/config/ipselect" ] && cp -f "/etc/config/ipselect" "$BACKUP_CFG"
tar -xzf "$DIR/data.tar.gz" -C /
if [ -f "$BACKUP_CFG" ]; then
  mv -f "/etc/config/ipselect" "/tmp/ipselect_new.default" 2>/dev/null || true
  cp -f "$BACKUP_CFG" "/etc/config/ipselect"
  rm -f "$BACKUP_CFG"
fi
chmod 755 /usr/bin/ipselect-runner /etc/init.d/ipselect
/etc/init.d/ipselect enable
/etc/init.d/ipselect restart
rm -rf /tmp/luci-indexcache* /tmp/luci-modulecache* /var/luci-indexcache* 2>/dev/null || true
/etc/init.d/rpcd restart 2>/dev/null || true
/etc/init.d/uhttpd restart 2>/dev/null || true
echo "安装完成！"
