#!/bin/sh
set -e
DIR="$(cd "$(dirname "$0")" && pwd)"
tar -xzf "$DIR/data.tar.gz" -C /
chmod 755 /usr/bin/ipselect-runner /etc/init.d/ipselect
/etc/init.d/ipselect enable
/etc/init.d/ipselect restart
rm -rf /tmp/luci-indexcache* /tmp/luci-modulecache* /var/luci-indexcache* 2>/dev/null || true
/etc/init.d/rpcd restart 2>/dev/null || true
/etc/init.d/uhttpd restart 2>/dev/null || true
echo "安装完成！"
