#!/bin/sh
# ==============================================================================
# luci-app-ipselect 卸载清理脚本 (适用于 OpenWrt 25 / iStoreOS 25)
# ==============================================================================
set -e

echo "正在卸载 luci-app-ipselect ..."
/etc/init.d/ipselect stop 2>/dev/null || true
/etc/init.d/ipselect disable 2>/dev/null || true

rm -f /etc/config/ipselect
rm -f /etc/init.d/ipselect
rm -f /usr/bin/ipselect-runner
rm -f /usr/share/luci/menu.d/luci-app-ipselect.json
rm -f /usr/share/rpcd/acl.d/luci-app-ipselect.json
rm -f /usr/lib/lua/luci/controller/ipselect.lua
rm -f /www/luci-static/resources/view/ipselect/overview.js
rm -rf /www/luci-static/resources/view/ipselect

rm -rf /tmp/luci-indexcache* /tmp/luci-modulecache* /var/luci-indexcache* 2>/dev/null || true
/etc/init.d/rpcd restart 2>/dev/null || true
/etc/init.d/uhttpd restart 2>/dev/null || true

echo "卸载完成！"
exit 0
